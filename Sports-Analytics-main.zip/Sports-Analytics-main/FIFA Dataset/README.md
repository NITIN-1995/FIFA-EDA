In this, we will be using EDA to conclude the following points:
1. World Statistics
2. Clustering Players by Nationality
3. Value and Wages of players with age.
4. Value of players with position
5. Overall and Potential with age
6. Variation of overall and potential by country for top countries
7. Correlation Matrix- attributes vs potential and overall
8. Variation in wages for top clubs
9. Age vs overall clustered by filed position
10. Make your dream team
11. Predicting playing position using player statistics
