The dataset is taken from Kaggle ( https://www.kaggle.com/josephgpinto/ipl-data-analysis/data ) . 


